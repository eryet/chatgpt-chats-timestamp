// #region Settings
const defaultI18n = {
  exportChatContainerMissing: "Could not find chat container",
  exportNoMessages: "No messages found in this chat",
  exportExtractFailed: "Could not extract message content",
  exportFailedTemplate: "Export failed: {{error}}",
  untitledChat: "Untitled Chat",
  exportCreatedLabel: "Created",
  exportRoleYou: "You",
  exportRoleChatgpt: "ChatGPT",
  exportPlaceholderImage: "[Image]",
  exportPlaceholderFileTemplate: "[File: {{fileName}}]",
};

let userSettings = {
  dateFormat: "locale",
  displayMode: "created",
  hoverMode: "swap",
  chatTimestampEnabled: true,
  chatTimestampPosition: "center",
  sidebarFilterMode: "all",
  starredIds: new Set(),
};

let userI18n = { ...defaultI18n };
// #endregion

function formatTemplate(template, values) {
  if (!template) return "";
  return template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, key) => {
    if (values && values[key] != null) {
      return String(values[key]);
    }
    return "";
  });
}

function normalizeStarredIdSet(value) {
  if (value instanceof Set) return value;
  if (Array.isArray(value)) return new Set(value);
  return new Set();
}

function getConversationIdFromHref(href) {
  if (!href) return null;

  try {
    const url = new URL(href, window.location.origin);
    const segments = url.pathname.split("/").filter(Boolean);
    // Regular chats live under /c/<id>, group chats under /gg/<id>
    const chatIndex = segments.indexOf("c");
    if (chatIndex !== -1 && segments[chatIndex + 1]) {
      return decodeURIComponent(segments[chatIndex + 1]);
    }
    const groupIndex = segments.indexOf("gg");
    if (groupIndex !== -1 && segments[groupIndex + 1]) {
      return decodeURIComponent(segments[groupIndex + 1]);
    }
    return null;
  } catch {
    return null;
  }
}

// Group chat rooms and thread conversation objects expose reactive fields as
// `$`-suffixed getter functions (e.g. updatedAt$, name$, serverId$). Read one
// defensively.
function readSignal(obj, key) {
  const getter = obj?.[key];
  if (typeof getter !== "function") return null;
  try {
    return getter.call(obj);
  } catch {
    return null;
  }
}

function isGroupRoom(candidate) {
  return Boolean(candidate?.id && typeof candidate.updatedAt$ === "function");
}

// room.createdAt is the client-side instantiation time of the room object,
// not when the room was created. The earliest loaded message (the "X created
// the group chat" notice) is the real creation time, but only trust it once
// the beginning of history has been fetched.
function getGroupRoomCreatedAt(room) {
  if (readSignal(room, "hasFetchedBeginning$") !== true) return null;
  const messages = readSignal(room, "messages$");
  const first = Array.isArray(messages) ? messages[0] : null;
  return first?.createdAt || null;
}

// New chats (including ones created on the Work surface) first live at
// /c/WEB:<uuid> — a client-side draft id. The server then assigns an
// unrelated real id; the URL flips to it quickly, but the sidebar item's
// href and fiber props can keep the draft id for minutes.
const DRAFT_CONVERSATION_ID_PREFIX = "WEB:";

function isDraftConversationId(id) {
  return typeof id === "string" && id.startsWith(DRAFT_CONVERSATION_ID_PREFIX);
}

// Draft id -> real server id, observed via recordDraftIdMapping().
const draftIdMap = new Map();

// Thread views attach a `conversation` object ({id, serverId$, ...}) a few
// fibers above each div[data-message-id]. For chats created this session,
// `id` keeps the WEB: draft id while serverId$() yields the real id.
function findThreadConversation() {
  const div = document.querySelector("div[data-message-id]");
  if (!div) return null;
  const fiberKey = Object.keys(div).find((k) => k.startsWith("__reactFiber$"));
  if (!fiberKey) return null;
  let fiber = div[fiberKey];
  let depth = 0;
  while (fiber && depth < 30) {
    const conversation = fiber.memoizedProps?.conversation;
    if (typeof conversation?.id === "string") return conversation;
    fiber = fiber.return;
    depth++;
  }
  return null;
}

function recordDraftIdMapping() {
  const conversation = findThreadConversation();
  if (!conversation || !isDraftConversationId(conversation.id)) return;
  const serverId = readSignal(conversation, "serverId$");
  if (typeof serverId === "string" && !isDraftConversationId(serverId)) {
    draftIdMap.set(conversation.id, serverId);
  }
}

function resolveConversationId(id) {
  if (!isDraftConversationId(id)) return id;
  return draftIdMap.get(id) || id;
}

// Regular chat links (/c/...), project chat links (/g/g-p-.../c/...),
// project folders (/g/g-p-.../project), and group chats (/gg/...)
const SIDEBAR_LINK_SELECTOR =
  'a[href^="/c/"], a[href*="/c/"][data-sidebar-item="true"], a[href$="/project"][data-sidebar-item="true"], a[href^="/gg/"]';

function isGroupChatPath(pathname) {
  return pathname.split("/").filter(Boolean)[0] === "gg";
}

// Locate the room object for the currently open group chat by walking the
// fiber of its sidebar link (rooms are not reachable from message fibers).
function findGroupRoomForCurrentPath() {
  const roomId = getConversationIdFromHref(window.location.href);
  const links = document.querySelectorAll('a[href^="/gg/"]');
  for (const link of links) {
    const fiberKey = Object.keys(link).find((k) =>
      k.startsWith("__reactFiber$"),
    );
    if (!fiberKey) continue;
    let fiber = link[fiberKey];
    let depth = 0;
    while (fiber && depth < 25) {
      const room = fiber.memoizedProps?.room;
      if (isGroupRoom(room)) {
        if (!roomId || room.id === roomId) return room;
        break;
      }
      fiber = fiber.return;
      depth++;
    }
  }
  return null;
}

// Group chat message prop (internally "calpico") attached one fiber above
// each div[data-message-id] inside a room.
function extractGroupMessageFromDiv(div) {
  const fiberKey = Object.keys(div).find((k) => k.startsWith("__reactFiber$"));
  if (!fiberKey) return null;
  let fiber = div[fiberKey];
  let depth = 0;
  while (fiber && depth < 15) {
    const calpicoMessage = fiber.memoizedProps?.calpicoMessage;
    if (calpicoMessage) return calpicoMessage;
    fiber = fiber.return;
    depth++;
  }
  return null;
}

// Map a group message's accountUserId to a member display name, if the
// room's member profile snapshots expose one.
function resolveGroupSenderName(calpicoMessage, memberSnapshots) {
  const accountUserId = calpicoMessage?.accountUserId;
  if (!accountUserId || !memberSnapshots) return null;
  let entries;
  if (memberSnapshots instanceof Map) {
    entries = [...memberSnapshots.values()];
  } else if (Array.isArray(memberSnapshots)) {
    entries = memberSnapshots;
  } else if (typeof memberSnapshots === "object") {
    entries = Object.values(memberSnapshots);
  } else {
    return null;
  }
  for (const entry of entries) {
    if (!entry || typeof entry !== "object") continue;
    const id =
      entry.accountUserId ||
      entry.account_user_id ||
      entry.userId ||
      entry.user_id ||
      entry.id;
    if (id !== accountUserId) continue;
    const name = entry.name || entry.displayName || entry.display_name;
    if (typeof name === "string" && name.trim()) return name.trim();
    break;
  }
  return null;
}

// First non-empty text inside a sidebar link, skipping the injected
// timestamp container. Suffix badges ("Work") are separate spans after the
// title, so the first text node is the title.
function findFirstTitleText(el) {
  for (const node of el.childNodes) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent.trim();
      if (text) return text;
    }
    if (node.nodeType === Node.ELEMENT_NODE) {
      if (node.classList?.contains("timestamp-stack-container")) continue;
      const text = findFirstTitleText(node);
      if (text) return text;
    }
  }
  return null;
}

// Title as rendered in the sidebar for a conversation id. Fiber titles lag
// for freshly created chats (null / "New chat"); the DOM shows the real one.
function getSidebarTitleForConversationId(conversationId) {
  if (!conversationId) return null;
  const links = document.querySelectorAll(SIDEBAR_LINK_SELECTOR);
  for (const el of links) {
    const linkId = resolveConversationId(
      getConversationIdFromHref(el.getAttribute("href")),
    );
    if (linkId !== conversationId) continue;
    return findFirstTitleText(el);
  }
  return null;
}

// Chat context for the popup. Resolves WEB: draft ids to the real
// conversation id so bookmarks are never keyed by a temporary id, and reads
// the title from the sidebar DOM because document.title stays generic while
// a chat is being created.
function getChatContext() {
  recordDraftIdMapping();
  const conversationId = resolveConversationId(
    getConversationIdFromHref(window.location.href),
  );
  const isDraft = isDraftConversationId(conversationId);
  const title =
    (!isDraft && getSidebarTitleForConversationId(conversationId)) ||
    document.title ||
    "";
  return {
    success: true,
    href: window.location.href,
    title,
    conversationId: isDraft ? null : conversationId,
    isDraft,
  };
}

function findFirstTitleTextRect(el) {
  for (const node of el.childNodes) {
    if (node.nodeType === Node.TEXT_NODE) {
      if (!node.textContent.trim()) continue;
      const range = document.createRange();
      range.selectNode(node);
      return range.getClientRects()[0] || range.getBoundingClientRect();
    }
    if (node.nodeType === Node.ELEMENT_NODE) {
      if (node.classList?.contains("timestamp-stack-container")) continue;
      const rect = findFirstTitleTextRect(node);
      if (rect) return rect;
    }
  }
  return null;
}

function linkHasLeadingIcon(el) {
  // Pinned chats render an icon before the title, which pushes the title
  // text to the right. Detect by measuring the gap between the link's left
  // edge and where the title text actually starts. Subtree icon scans give
  // false positives because regular chats also contain hover-revealed action
  // icons (menu "...", etc.).
  try {
    const linkRect = el.getBoundingClientRect();
    if (!linkRect.width) return false;

    const titleRect = findFirstTitleTextRect(el);
    if (!titleRect || !titleRect.width) return false;

    return titleRect.left - linkRect.left >= 24;
  } catch {
    return false;
  }
}

const STAR_ICON_SVG =
  '<svg viewBox="0 0 16 16" aria-hidden="true" style="display:block;width:100%;height:100%;fill:currentColor"><path d="M8 .25a.75.75 0 0 1 .673.418l1.882 3.815 4.21.612a.75.75 0 0 1 .416 1.279l-3.046 2.97.719 4.192a.751.751 0 0 1-1.088.791L8 12.347l-3.766 1.98a.75.75 0 0 1-1.088-.79l.72-4.194L.818 6.374a.75.75 0 0 1 .416-1.28l4.21-.611L7.327.668A.75.75 0 0 1 8 .25Zm0 2.445L6.615 5.5a.75.75 0 0 1-.564.41l-3.097.45 2.24 2.184a.75.75 0 0 1 .216.664l-.528 3.084 2.769-1.456a.75.75 0 0 1 .698 0l2.77 1.456-.53-3.084a.75.75 0 0 1 .216-.664l2.24-2.183-3.096-.45a.75.75 0 0 1-.564-.41L8 2.694Z"></path></svg>';

// #region Event Listeners
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.data?.type === "TIMESTAMP_SETTINGS_UPDATE") {
    userSettings = { ...userSettings, ...event.data.settings };
    userSettings.starredIds = normalizeStarredIdSet(userSettings.starredIds);
    if (event.data?.i18n) {
      const nextI18n = { ...defaultI18n };
      Object.entries(event.data.i18n).forEach(([key, value]) => {
        if (value) nextI18n[key] = value;
      });
      userI18n = nextI18n;
    }

    // Clear chat timestamp marks when settings change to force re-render
    document.querySelectorAll("div[data-message-id]").forEach((div) => {
      if (div.dataset.timestampAdded) {
        const existingTimestamp = div.querySelector(".chatgpt-timestamp");
        if (existingTimestamp) {
          existingTimestamp.remove();
        }
        delete div.dataset.timestampAdded;
      }
    });

    addSidebarTimestampsFiber(); // Refresh sidebar with new settings
    addChatTimestamps(); // Refresh chat messages with new settings
  }

  if (event.data?.type === "GET_CHAT_CONTEXT") {
    window.postMessage(
      {
        type: "GET_CHAT_CONTEXT_RESULT",
        result: getChatContext(),
      },
      window.location.origin,
    );
  }

  if (event.data?.type === "EXPORT_CHAT") {
    const result = exportCurrentChat(event.data.format);
    window.postMessage(
      {
        type: "EXPORT_CHAT_RESULT",
        result: result,
      },
      window.location.origin,
    );
  }

});
// #endregion

// #region Export
function exportCurrentChat(format = "markdown") {
  try {
    // Find the conversation data from React fiber
    const mainElement = document.querySelector("main");
    if (!mainElement) {
      return { success: false, message: userI18n.exportChatContainerMissing };
    }

    const isGroupChat = isGroupChatPath(window.location.pathname);

    // Get conversation metadata from sidebar first (needed for title)
    let conversationMeta = null;
    let groupRoom = null;
    let title;

    if (isGroupChat) {
      groupRoom = findGroupRoomForCurrentPath();
      if (groupRoom) {
        conversationMeta = {
          create_time: getGroupRoomCreatedAt(groupRoom),
          update_time: readSignal(groupRoom, "updatedAt$"),
        };
      }
      const roomName = readSignal(groupRoom, "name$");
      title =
        (typeof roomName === "string" && roomName.trim()) ||
        document.title.replace(/\s+-\s+ChatGPT$/i, "").trim() ||
        userI18n.untitledChat;
    } else {
      // Select both regular chat links and project chat links
      const sidebarLinks = document.querySelectorAll(
        'a[href^="/c/"], a[href*="/c/"][data-sidebar-item="true"]',
      );
      const currentPath = window.location.pathname;
      // Match on resolved ids too: for freshly created chats the sidebar
      // href can still hold the WEB: draft id while the URL has the real id.
      const canonicalId = resolveConversationId(
        getConversationIdFromHref(window.location.href),
      );

      for (const link of sidebarLinks) {
        const linkId = resolveConversationId(
          getConversationIdFromHref(link.getAttribute("href")),
        );
        if (
          (canonicalId && linkId === canonicalId) ||
          link.getAttribute("href") === currentPath ||
          link.classList.contains("bg-token-sidebar-surface-secondary")
        ) {
          const fiberKey = Object.keys(link).find((k) =>
            k.startsWith("__reactFiber$"),
          );
          if (fiberKey) {
            let fiber = link[fiberKey];
            let depth = 0;
            while (fiber && depth < 25) {
              const props = fiber.memoizedProps;
              // Sidebar items pass the conversation as `historyItem` since the
              // 2026-03 sidebar rework (`conversation` kept for project chats).
              const candidate = props?.conversation || props?.historyItem;
              if (candidate?.create_time) {
                conversationMeta = candidate;
                break;
              }
              fiber = fiber.return;
              depth++;
            }
          }
          if (conversationMeta) break;
        }
      }

      // Get conversation title from sidebar metadata; freshly created chats
      // carry a stale fiber title (null / "New chat"), so fall back to the
      // rendered sidebar text.
      title =
        conversationMeta?.title?.trim() ||
        getSidebarTitleForConversationId(canonicalId) ||
        userI18n.untitledChat;
    }

    // Collect all messages
    const messageDivs = document.querySelectorAll("div[data-message-id]");
    if (messageDivs.length === 0) {
      return { success: false, message: userI18n.exportNoMessages };
    }

    const messages = [];
    const imagePlaceholder =
      userI18n.exportPlaceholderImage || defaultI18n.exportPlaceholderImage;
    const filePlaceholderTemplate =
      userI18n.exportPlaceholderFileTemplate ||
      defaultI18n.exportPlaceholderFileTemplate;

    if (isGroupChat) {
      // members$ is the live member directory ({accountUserId, name, ...});
      // memberProfileSnapshots$ stays empty even in populated rooms, so only
      // use it as a fallback.
      const members = readSignal(groupRoom, "members$");
      const memberSnapshots =
        Array.isArray(members) && members.length > 0
          ? members
          : readSignal(groupRoom, "memberProfileSnapshots$");
      messageDivs.forEach((div) => {
        // Assistant bubbles nest per-segment divs with their own
        // data-message-id — only the outermost div is one message.
        if (div.parentElement?.closest("div[data-message-id]")) return;
        const calpicoMessage = extractGroupMessageFromDiv(div);
        // Skip room notices ("X created the group chat")
        if (!calpicoMessage || calpicoMessage.role === "system") return;

        let contentReferences = [];
        const chunks = [];
        const rawMessages = Array.isArray(calpicoMessage.rawMessages)
          ? calpicoMessage.rawMessages
          : [];
        rawMessages.forEach((raw) => {
          const parts = raw?.content?.parts;
          if (Array.isArray(parts)) {
            parts.forEach((part) => {
              if (typeof part === "string" && part.trim()) chunks.push(part);
            });
          }
          const refs = raw?.metadata?.content_references;
          if (Array.isArray(refs) && refs.length > 0) {
            contentReferences = contentReferences.concat(refs);
          }
        });

        let content = chunks.join("\n");
        if (!content && typeof calpicoMessage.content?.text === "string") {
          content = calpicoMessage.content.text;
        }
        if (!content && typeof calpicoMessage.preview === "string") {
          content = calpicoMessage.preview;
        }
        if (!content.trim()) return;

        let timestamp = calpicoMessage.createdAt
          ? new Date(calpicoMessage.createdAt)
          : null;
        if (timestamp && Number.isNaN(timestamp.getTime())) timestamp = null;

        messages.push({
          turnIndex: null,
          role: calpicoMessage.role || "unknown",
          senderName: resolveGroupSenderName(calpicoMessage, memberSnapshots),
          content: content.trim(),
          timestamp,
          contentReferences,
        });
      });
    } else {
      messageDivs.forEach((div) => {
        const fiberKey = Object.keys(div).find((k) =>
          k.startsWith("__reactFiber$"),
        );
        if (!fiberKey) return;

        let fiber = div[fiberKey];
        let depth = 0;
        let messageData = null;
        let turnIndex = null;
        let contentReferences = [];

        while (fiber && depth < 150) {
          const props = fiber.memoizedProps;

          // Get turnIndex
          if (turnIndex == null && props?.turnIndex != null) {
            turnIndex = props.turnIndex;
          }

          // Get message data
          if (!messageData && props?.message?.content?.parts) {
            messageData = props.message;
          }

          // Get content_references for citations
          if (
            contentReferences.length === 0 &&
            props?.message?.metadata?.content_references?.length > 0
          ) {
            contentReferences = props.message.metadata.content_references;
          }

          if (messageData && turnIndex != null) break;
          fiber = fiber.return;
          depth++;
        }

        if (!messageData) return;

        const role = messageData.author?.role || "unknown";
        // Handle parts that can be strings or objects (like images)
        const parts = messageData.content?.parts || [];
        const contentParts = parts.map((part) => {
          if (typeof part === "string") {
            return part;
          }
          // Handle image/file objects
          if (part && typeof part === "object") {
            // Image asset pointer
            // Note: Image URLs from ChatGPT are not directly viewable (they prompt download)
            // and require authentication, so we just mark them as [Image] placeholder
            if (
              part.asset_pointer ||
              part.content_type === "image_asset_pointer"
            ) {
              return imagePlaceholder;
            }
            // File attachment
            if (part.name && part.content_type) {
              return formatTemplate(filePlaceholderTemplate, {
                fileName: part.name,
              });
            }
            // Generic object - skip
            return "";
          }
          return "";
        });
        const content = contentParts.filter(Boolean).join("\n");
        const timestamp = messageData.create_time
          ? new Date(messageData.create_time * 1000)
          : null;

        if (content.trim()) {
          messages.push({
            turnIndex,
            role,
            content: content.trim(),
            timestamp,
            contentReferences,
          });
        }
      });
    }

    if (messages.length === 0) {
      return { success: false, message: userI18n.exportExtractFailed };
    }

    // Helper function to process citations in content
    function processCitations(content, contentReferences, format) {
      if (!contentReferences || contentReferences.length === 0) {
        // Remove orphan citation markers
        return content.replace(
          /\s*citeturn\d+search\d+(?:turn\d+search\d+)*/gi,
          "",
        );
      }

      let processedContent = content;
      const citationMap = new Map();

      // Build citation map from content_references
      contentReferences.forEach((ref) => {
        if (!ref || typeof ref !== "object") return;

        const matchedText = ref.matched_text;
        const alt = ref.alt; // Pre-formatted markdown like "([Title](url))"
        const safeUrls = ref.safe_urls || [];
        const type = ref.type;

        // Skip non-citation types
        if (type === "sources_footnote" || !matchedText || matchedText === " ")
          return;

        if (matchedText && (safeUrls.length > 0 || alt)) {
          // Get the first non-utm URL or the first URL
          const url =
            safeUrls.find((u) => !u.includes("utm_source")) ||
            safeUrls[0] ||
            "";

          // Map the matched_text to citation info
          citationMap.set(matchedText.toLowerCase(), { url, alt });
        }
      });

      if (citationMap.size === 0) {
        // No valid citations, just clean up markers
        return processedContent.replace(
          /\s*citeturn\d+search\d+(?:turn\d+search\d+)*/gi,
          "",
        );
      }

      // Replace citation markers with proper formatted links
      // Sort by length descending to match longer patterns first
      const sortedMarkers = [...citationMap.keys()].sort(
        (a, b) => b.length - a.length,
      );

      for (const marker of sortedMarkers) {
        const cite = citationMap.get(marker);
        // Create case-insensitive regex for this marker
        const regex = new RegExp(
          marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
          "gi",
        );

        processedContent = processedContent.replace(regex, () => {
          if (format === "markdown" && cite.alt) {
            return ` ${cite.alt}`;
          } else if (format === "plain" && cite.url) {
            try {
              const domain = new URL(cite.url).hostname.replace("www.", "");
              return ` [${domain}]`;
            } catch {
              return "";
            }
          }
          return "";
        });
      }

      // Clean up any remaining unmatched citation markers
      return processedContent.replace(
        /\s*citeturn\d+search\d+(?:turn\d+search\d+)*/gi,
        "",
      );
    }

    // Format output based on requested format
    let output = "";
    const dateFormat = userSettings.dateFormat || "locale";
    const createdLabel =
      userI18n.exportCreatedLabel || defaultI18n.exportCreatedLabel;
    const roleYou = userI18n.exportRoleYou || defaultI18n.exportRoleYou;
    const roleChatgpt =
      userI18n.exportRoleChatgpt || defaultI18n.exportRoleChatgpt;

    if (format === "markdown") {
      output = `# ${title}\n\n`;
      if (conversationMeta?.create_time) {
        const created = new Date(conversationMeta.create_time);
        output += `**${createdLabel}:** ${formatDate(created, dateFormat)}\n\n`;
      }
      output += `---\n\n`;

      messages.forEach((msg) => {
        const senderLabel =
          msg.senderName || (msg.role === "user" ? roleYou : roleChatgpt);
        const roleLabel = `**${senderLabel}**`;
        const turnStr = msg.turnIndex != null ? `#${msg.turnIndex} ` : "";
        const timeStr = msg.timestamp
          ? ` *(${formatDate(msg.timestamp, dateFormat)})*`
          : "";

        const processedContent = processCitations(
          msg.content,
          msg.contentReferences,
          "markdown",
        );
        output += `### ${turnStr}${roleLabel}${timeStr}\n\n${processedContent}\n\n---\n\n`;
      });
    } else if (format === "plain") {
      output = `${title}\n${"=".repeat(title.length)}\n\n`;
      if (conversationMeta?.create_time) {
        const created = new Date(conversationMeta.create_time);
        output += `${createdLabel}: ${formatDate(created, dateFormat)}\n\n`;
      }

      messages.forEach((msg) => {
        const roleLabel =
          msg.senderName || (msg.role === "user" ? roleYou : roleChatgpt);
        const turnStr = msg.turnIndex != null ? `#${msg.turnIndex} ` : "";
        const timeStr = msg.timestamp
          ? ` (${formatDate(msg.timestamp, dateFormat)})`
          : "";

        const processedContent = processCitations(
          msg.content,
          msg.contentReferences,
          "plain",
        );
        output += `[${turnStr}${roleLabel}]${timeStr}:\n${processedContent}\n\n`;
      });
    } else if (format === "json") {
      const exportData = {
        title,
        created: conversationMeta?.create_time
          ? new Date(conversationMeta.create_time).toISOString()
          : null,
        updated: conversationMeta?.update_time
          ? new Date(conversationMeta.update_time).toISOString()
          : null,
        messageCount: messages.length,
        messages: messages.map((msg) => ({
          turn: msg.turnIndex,
          role: msg.role,
          sender: msg.senderName || null,
          content: processCitations(msg.content, msg.contentReferences, "json"),
          timestamp: msg.timestamp ? msg.timestamp.toISOString() : null,
        })),
      };
      output = JSON.stringify(exportData, null, 2);
    }

    return {
      success: true,
      content: output,
      messageCount: messages.length,
      title: title,
    };
  } catch (error) {
    return {
      success: false,
      message: formatTemplate(userI18n.exportFailedTemplate, {
        error: error.message,
      }),
    };
  }
}
// #endregion

// #region Utils
function formatTimestamp(value) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return formatDate(d, userSettings.dateFormat);
}

function setHoverExpanded(el, expanded) {
  const container = el.querySelector(":scope > .timestamp-stack-container");
  if (!container) return;

  const secondaryEl = container.querySelector(":scope > .timestamp-secondary");
  if (!secondaryEl) return;

  // Only expand if hover mode is classic and there's secondary content
  const hasSecondary = !!secondaryEl.textContent;
  const shouldExpand =
    expanded && hasSecondary && userSettings.hoverMode === "classic";
  secondaryEl.style.display = shouldExpand ? "block" : "none";
  el.style.paddingBottom = shouldExpand ? "28px" : "15px";
}
// #endregion

// #region Sidebar
function addSidebarTimestampsFiber() {
  const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const starredIds = normalizeStarredIdSet(userSettings.starredIds);
  const links = document.querySelectorAll(SIDEBAR_LINK_SELECTOR);

  const primaryColor = isDark ? "#e3e3e3" : "#4B5563";
  const secondaryColor = isDark ? "#81c995" : "#15803D";

  links.forEach((el) => {
    // find fiber and conversation/gizmo data
    const fiberKey = Object.keys(el).find((k) => k.startsWith("__reactFiber$"));
    if (!fiberKey) return;

    let fiber = el[fiberKey];
    let depth = 0;
    let conversation = null;
    let gizmo = null;
    let room = null;
    while (fiber && depth < 25) {
      const props = fiber.memoizedProps;
      // Sidebar items pass the conversation as `historyItem` since the
      // 2026-03 sidebar rework (`conversation` kept for project chats).
      const candidate = props?.conversation || props?.historyItem;
      if (candidate?.create_time) {
        conversation = candidate;
        break;
      }
      // Project folders have gizmo.gizmo.created_at
      if (props?.gizmo?.gizmo?.created_at) {
        gizmo = props.gizmo.gizmo;
        break;
      }
      // Group chats (GROUP_DM rooms)
      if (isGroupRoom(props?.room)) {
        room = props.room;
        break;
      }
      fiber = fiber.return;
      depth++;
    }

    const conversationId = resolveConversationId(
      conversation?.id ||
        room?.id ||
        getConversationIdFromHref(el.getAttribute("href")),
    );
    const isStarred = Boolean(conversationId && starredIds.has(conversationId));

    if (conversationId) {
      el.style.display =
        userSettings.sidebarFilterMode === "starred" && !isStarred ? "none" : "";
    } else {
      el.style.display = "";
    }

    // Get timestamps from conversation, gizmo, or group chat room
    let createdText, updatedText;
    if (conversation?.create_time) {
      createdText = formatTimestamp(conversation.create_time);
      updatedText = formatTimestamp(conversation.update_time);
    } else if (gizmo?.created_at) {
      createdText = formatTimestamp(gizmo.created_at);
      updatedText = formatTimestamp(gizmo.updated_at);
    } else if (room) {
      // Rooms whose history isn't loaded expose no creation time; fall back
      // to last activity rather than showing nothing (or a bogus date).
      updatedText = formatTimestamp(readSignal(room, "updatedAt$"));
      createdText = formatTimestamp(getGroupRoomCreatedAt(room)) || updatedText;
    } else {
      return;
    }
    if (!createdText) return;

    // Determine what to show based on settings
    const { displayMode, hoverMode } = userSettings;
    const hoverActive = hoverMode !== "disabled";

    let primaryText, secondaryText;
    if (displayMode === "updated") {
      // Show updated time by default, created on hover
      primaryText = updatedText || createdText;
      secondaryText = hoverActive && updatedText ? createdText : "";
    } else {
      // Show created time by default, updated on hover
      primaryText = createdText;
      secondaryText = hoverActive ? updatedText : "";
    }

    // Project chats have ps-9 class which adds extra left padding (36px).
    // Project folders have an icon, so use same offset.
    // Pinned chats (new sidebar section) have a leading icon inside the link
    // that pushes the title right without using ps-9 — match the title offset.
    const isProjectChat = el.classList.contains("ps-9");
    const isProjectFolder = el.getAttribute("href")?.endsWith("/project");
    const hasLeadingIcon =
      !isProjectChat && !isProjectFolder && linkHasLeadingIcon(el);
    const leftOffset =
      isProjectChat || isProjectFolder || hasLeadingIcon ? "36px" : "10px";

    let container = el.querySelector(":scope > .timestamp-stack-container");
    if (!container) {
      container = document.createElement("div");
      container.className = "timestamp-stack-container";
      container.style.cssText = `
        position: absolute;
        bottom: 4px;
        left: ${leftOffset};
        right: 10px;
        overflow: hidden;
        font-size: 10px;
        font-family: ui-monospace,'SF Mono',Monaco,monospace;
        opacity: 0.9;
        pointer-events: none;
        line-height: 12px;
        white-space: nowrap;
        padding-right: 14px;
      `;

      const secondaryLine = document.createElement("div");
      secondaryLine.className = "timestamp-secondary";
      secondaryLine.style.display = "none";
      secondaryLine.style.color = secondaryColor;

      const primaryLine = document.createElement("div");
      primaryLine.className = "timestamp-primary";
      primaryLine.style.color = primaryColor;

      container.appendChild(primaryLine);
      container.appendChild(secondaryLine);

      el.style.position = "relative";
      el.style.overflow = "hidden";
      el.appendChild(container);
    } else if (container.style.left !== leftOffset) {
      container.style.left = leftOffset;
    }

    const primaryLine = container.querySelector(":scope > .timestamp-primary");
    const secondaryLine = container.querySelector(
      ":scope > .timestamp-secondary",
    );
    if (!primaryLine || !secondaryLine) return;

    let starBadge = container.querySelector(":scope > .timestamp-star");
    if (!starBadge) {
      starBadge = document.createElement("span");
      starBadge.className = "timestamp-star";
      starBadge.style.cssText = `
        position: absolute;
        top: 0;
        right: 0;
        width: 11px;
        height: 11px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: ${isDark ? "#fbbf24" : "#b45309"};
        opacity: 0.95;
      `;
      starBadge.innerHTML = STAR_ICON_SVG;
      container.appendChild(starBadge);
    }

    primaryLine.style.color = primaryColor;
    secondaryLine.style.color = secondaryColor;
    primaryLine.style.paddingRight = "14px";
    secondaryLine.style.paddingRight = "14px";

    primaryLine.textContent = primaryText;
    secondaryLine.textContent = secondaryText;
    starBadge.innerHTML = STAR_ICON_SVG;
    starBadge.style.display = isStarred ? "flex" : "none";
    starBadge.style.color = isDark ? "#fbbf24" : "#b45309";

    // Handle display based on hover mode
    if (!hoverActive || !secondaryText) {
      // No hover - hide secondary, reset swap styles
      secondaryLine.style.display = "none";
      el.style.paddingBottom = "15px";
      primaryLine.style.transition = "none";
      primaryLine.style.transform = "none";
      primaryLine.style.opacity = "";
      secondaryLine.style.opacity = "";
      container.classList.remove("timestamp-swap-mode");
    } else if (hoverMode === "swap") {
      // Swap mode - primary slides up & fades, secondary slides up from below
      el.style.paddingBottom = "15px";
      container.classList.add("timestamp-swap-mode");
      container.style.overflow = "hidden";

      // Primary line setup
      primaryLine.style.display = "block";
      primaryLine.style.transition =
        "transform .3s cubic-bezier(0.76, 0, 0.24, 1), opacity .3s ease";
      primaryLine.style.transform = "translateY(0)";
      primaryLine.style.opacity = "1";

      // Secondary line: stacked on top, starts below
      secondaryLine.style.position = "absolute";
      secondaryLine.style.top = "0";
      secondaryLine.style.left = "0";
      secondaryLine.style.right = "0";
      secondaryLine.style.display = "block";
      secondaryLine.style.transition =
        "transform .3s cubic-bezier(0.76, 0, 0.24, 1), opacity .3s ease";
      secondaryLine.style.transform = "translateY(100%)";
      secondaryLine.style.opacity = "0";

      if (!el.dataset.timestampSwapBound) {
        const swapIn = () => {
          if (userSettings.hoverMode !== "swap") return;
          const p = el.querySelector(".timestamp-primary");
          const s = el.querySelector(".timestamp-secondary");
          if (p) {
            p.style.transform = "translateY(-100%)";
            p.style.opacity = "0";
          }
          if (s) {
            s.style.transform = "translateY(0)";
            s.style.opacity = "1";
          }
        };
        const swapOut = () => {
          if (userSettings.hoverMode !== "swap") return;
          const p = el.querySelector(".timestamp-primary");
          const s = el.querySelector(".timestamp-secondary");
          if (p) {
            p.style.transform = "translateY(0)";
            p.style.opacity = "1";
          }
          if (s) {
            s.style.transform = "translateY(100%)";
            s.style.opacity = "0";
          }
        };
        el.addEventListener("mouseenter", swapIn);
        el.addEventListener("mouseleave", swapOut);
        el.addEventListener("focusin", swapIn);
        el.addEventListener("focusout", swapOut);
        el.dataset.timestampSwapBound = "true";
      }

      // Keep the right state if the loop runs while hovered
      const isHovered = el.matches(":hover");
      const isFocused = el.contains(document.activeElement);
      if (isHovered || isFocused) {
        primaryLine.style.transform = "translateY(-100%)";
        primaryLine.style.opacity = "0";
        secondaryLine.style.transform = "translateY(0)";
        secondaryLine.style.opacity = "1";
      }
    } else if (hoverMode === "classic") {
      // Classic mode - show secondary line below on hover
      container.classList.remove("timestamp-swap-mode");
      primaryLine.style.transition = "none";
      primaryLine.style.transform = "none";
      primaryLine.style.opacity = "";
      secondaryLine.style.position = "";
      secondaryLine.style.top = "";
      secondaryLine.style.left = "";
      secondaryLine.style.right = "";
      secondaryLine.style.transition = "";
      secondaryLine.style.transform = "";
      secondaryLine.style.transformOrigin = "";
      secondaryLine.style.opacity = "";

      if (!el.dataset.timestampHoverBound) {
        const expand = () => setHoverExpanded(el, true);
        const collapse = () => setHoverExpanded(el, false);
        el.addEventListener("mouseenter", expand);
        el.addEventListener("mouseleave", collapse);
        el.addEventListener("focusin", expand);
        el.addEventListener("focusout", collapse);
        el.dataset.timestampHoverBound = "true";
      }

      // Keep the right state if the loop runs while hovered
      const isHovered = el.matches(":hover");
      const isFocused = el.contains(document.activeElement);
      setHoverExpanded(el, isHovered || isFocused);
    }

    el.dataset.timestampAdded = "true";
  });
}
// #endregion

// #region Chat
function addChatTimestamps() {
  const { chatTimestampEnabled, chatTimestampPosition, dateFormat } =
    userSettings;
  const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const timestampColor = isDark ? "#afafaf" : "#4B5563";

  const justifyContent =
    chatTimestampPosition === "left"
      ? "flex-start"
      : chatTimestampPosition === "right"
        ? "flex-end"
        : "center";

  // Group chat rooms natively show message times, so no stamps are added
  // there — only clean up leftovers (e.g. added by an older version).
  const isGroupChat = isGroupChatPath(window.location.pathname);

  document.querySelectorAll("div[data-message-id]").forEach((div) => {
    let timestampEl = div.querySelector(":scope > .chatgpt-timestamp");

    // If chat timestamps are disabled, remove any existing ones and clear marker.
    if (!chatTimestampEnabled || isGroupChat) {
      div
        .querySelectorAll(".chatgpt-timestamp")
        .forEach((el) => el.remove());
      delete div.dataset.timestampAdded;
      return;
    }

    // Skip if already processed and has timestamp.
    if (div.dataset.timestampAdded && timestampEl) return;

    // Find fiber and traverse upwards to locate message timestamp.
    const fiberKey = Object.keys(div).find((k) =>
      k.startsWith("__reactFiber$"),
    );
    if (!fiberKey) return;

    let fiber = div[fiberKey];
    let depth = 0;
    let date = null;
    let turnIndex = null;
    while (fiber && depth < 150) {
      const props = fiber.memoizedProps;

      if (turnIndex == null) {
        const candidateTurnIndex = props?.turnIndex ?? null;
        if (candidateTurnIndex != null) turnIndex = candidateTurnIndex;
      }

      if (date == null) {
        const messages = props?.messages;
        const candidateSeconds = Number(messages?.[0]?.create_time);
        if (Number.isFinite(candidateSeconds)) {
          const candidate = new Date(candidateSeconds * 1000);
          if (!Number.isNaN(candidate.getTime())) date = candidate;
        }
      }

      if (date != null && turnIndex != null) break;
      fiber = fiber.return;
      depth++;
    }
    if (!date) return;

    const formatted = formatDate(date, dateFormat);
    if (!formatted) return;

    // Double-check that chat timestamps are still enabled before adding.
    if (!userSettings.chatTimestampEnabled) return;

    if (!timestampEl) {
      timestampEl = document.createElement("span");
      timestampEl.className = "chatgpt-timestamp";
      div.insertBefore(timestampEl, div.firstChild);
    }

    let indexEl = timestampEl.querySelector(":scope > .chatgpt-turn-index");
    let timeEl = timestampEl.querySelector(":scope > .chatgpt-turn-time");
    if (!indexEl || !timeEl) {
      timestampEl.textContent = "";
      indexEl = document.createElement("span");
      indexEl.className = "chatgpt-turn-index";
      timeEl = document.createElement("span");
      timeEl.className = "chatgpt-turn-time";
      timestampEl.append(indexEl, timeEl);
    }

    const indexText = turnIndex == null ? "" : `#${turnIndex}`;
    indexEl.textContent = indexText;
    indexEl.style.display = indexText ? "inline-block" : "none";
    timeEl.textContent = formatted;

    timestampEl.style.cssText = `
      font-size: 11px;
      color: ${timestampColor};
      font-weight: 600;
      margin-bottom: 4px;
      display: flex;
      width: 100%;
      align-items: baseline;
      justify-content: ${justifyContent};
      gap: 6px;
      font-family: ui-monospace, 'SF Mono', Monaco, monospace;
    `;
    indexEl.style.cssText = `
      opacity: 0.85;
      font-weight: 700;
    `;

    // Mark as processed.
    div.dataset.timestampAdded = "true";
  });
}
// #endregion

// #region Init
function startRehydrationLoop() {
  let lastCount = 0;
  setInterval(() => {
    // Keep the WEB: draft id -> real id map fresh so sidebar star badges and
    // popup lookups match chats created this session.
    recordDraftIdMapping();

    const chatLinks = document.querySelectorAll(SIDEBAR_LINK_SELECTOR);
    const currentCount = chatLinks.length;

    if (currentCount !== lastCount) {
      // console.log(
      //   `[Timestamp] sidebar count changed (${lastCount} → ${currentCount}) — refreshing`
      // );
      lastCount = currentCount;
      addSidebarTimestampsFiber();
    } else {
      addSidebarTimestampsFiber();
    }

    // Also update chat timestamps in the same loop
    addChatTimestamps();
  }, 1500);
}

setTimeout(startRehydrationLoop, 2000);
// #endregion
